"""
docx_reader.py
---------------
Utility functions to extract text from Microsoft Word (.docx) documents
using python-docx. Used as one of the ingestion sources for the
KnowledgeDesk RAG pipeline.
"""

from __future__ import annotations

import os
from typing import List, Dict

try:
    import docx  # python-docx
except ImportError:  # pragma: no cover
    docx = None


def extract_text_from_docx(file_path: str) -> str:
    """
    Extract raw text (paragraphs + table cells) from a single .docx file.

    Args:
        file_path: Path to the .docx file.

    Returns:
        A single string containing the extracted text.
    """
    if docx is None:
        raise ImportError("python-docx is not installed. Run: pip install python-docx")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"DOCX file not found: {file_path}")

    document = docx.Document(file_path)
    text_parts = []

    # Paragraphs
    for paragraph in document.paragraphs:
        if paragraph.text.strip():
            text_parts.append(paragraph.text)

    # Tables
    for table in document.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells)
            if row_text.strip(" |"):
                text_parts.append(row_text)

    return "\n".join(text_parts)


def load_all_docx(folder_path: str) -> List[Dict]:
    """
    Load and extract text from every DOCX file inside a folder.

    Args:
        folder_path: Directory containing .docx files.

    Returns:
        A list of dicts with keys: "source", "text".
    """
    documents = []
    if not os.path.isdir(folder_path):
        return documents

    for filename in sorted(os.listdir(folder_path)):
        if filename.lower().endswith(".docx"):
            full_path = os.path.join(folder_path, filename)
            try:
                text = extract_text_from_docx(full_path)
                documents.append({"source": filename, "text": text})
            except Exception as exc:  # pragma: no cover
                print(f"[docx_reader] Failed to read {filename}: {exc}")
    return documents


if __name__ == "__main__":
    sample_dir = os.path.join("data", "docx")
    docs = load_all_docx(sample_dir)
    print(f"Loaded {len(docs)} DOCX document(s) from {sample_dir}")
    for doc in docs:
        preview = doc["text"][:200].replace("\n", " ")
        print(f"- {doc['source']}: {preview}...")
