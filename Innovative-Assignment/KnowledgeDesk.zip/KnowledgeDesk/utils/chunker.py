"""
chunker.py
-----------
Splits large documents into overlapping chunks suitable for embedding
and retrieval. Wraps LangChain's RecursiveCharacterTextSplitter with a
sensible default configuration for enterprise knowledge documents.
"""

from __future__ import annotations

from typing import List, Dict

try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
except ImportError:  # pragma: no cover
    RecursiveCharacterTextSplitter = None

DEFAULT_CHUNK_SIZE = 800
DEFAULT_CHUNK_OVERLAP = 120


def get_text_splitter(
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
):
    """
    Build a configured RecursiveCharacterTextSplitter instance.
    """
    if RecursiveCharacterTextSplitter is None:
        raise ImportError("langchain is not installed. Run: pip install langchain")

    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )


def chunk_documents(
    documents: List[Dict],
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> List[Dict]:
    """
    Split a list of {"source": ..., "text": ...} documents into chunks.

    Args:
        documents: List of dicts with "source" and "text" keys.
        chunk_size: Max characters per chunk.
        chunk_overlap: Overlap in characters between consecutive chunks.

    Returns:
        List of dicts: [{"source": ..., "chunk_id": ..., "text": ...}, ...]
    """
    splitter = get_text_splitter(chunk_size, chunk_overlap)
    chunked = []

    for doc in documents:
        source = doc.get("source", "unknown")
        text = doc.get("text", "")
        if not text.strip():
            continue

        pieces = splitter.split_text(text)
        for idx, piece in enumerate(pieces):
            chunked.append(
                {
                    "source": source,
                    "chunk_id": f"{source}::chunk_{idx}",
                    "text": piece,
                }
            )

    return chunked


if __name__ == "__main__":
    demo_docs = [
        {
            "source": "demo.txt",
            "text": "This is a demo policy document. " * 50,
        }
    ]
    chunks = chunk_documents(demo_docs)
    print(f"Produced {len(chunks)} chunks from {len(demo_docs)} document(s)")
    if chunks:
        print("Sample chunk:", chunks[0]["text"][:150])
