"""
vector_store.py
-----------------
FAISS-based vector database wrapper. Handles building, saving, loading,
and querying a similarity-search index over embedded document chunks.
"""

from __future__ import annotations

import os
import json
import pickle
from typing import List, Dict, Tuple

import numpy as np

try:
    import faiss
except ImportError:  # pragma: no cover
    faiss = None

from utils.embeddings import embed_texts, embed_query

DEFAULT_INDEX_DIR = "vector_db"
INDEX_FILE_NAME = "faiss_index.bin"
METADATA_FILE_NAME = "metadata.pkl"


class VectorStore:
    """
    Thin wrapper around a FAISS FlatL2 index plus a parallel metadata
    store (list of chunk dicts) so we can map similarity results back
    to their original text and source document.
    """

    def __init__(self, dimension: int | None = None):
        if faiss is None:
            raise ImportError("faiss is not installed. Run: pip install faiss-cpu")
        self.dimension = dimension
        self.index = None
        self.metadata: List[Dict] = []

    def build(self, chunks: List[Dict]) -> None:
        """
        Build a fresh FAISS index from a list of chunk dicts
        (each containing at least a "text" key).
        """
        texts = [c["text"] for c in chunks]
        vectors = np.array(embed_texts(texts), dtype="float32")

        self.dimension = vectors.shape[1]
        self.index = faiss.IndexFlatL2(self.dimension)
        self.index.add(vectors)
        self.metadata = chunks

    def add(self, chunks: List[Dict]) -> None:
        """
        Add new chunks to an existing index (or build one if empty).
        """
        if self.index is None:
            self.build(chunks)
            return

        texts = [c["text"] for c in chunks]
        vectors = np.array(embed_texts(texts), dtype="float32")
        self.index.add(vectors)
        self.metadata.extend(chunks)

    def search(self, query: str, top_k: int = 4) -> List[Tuple[Dict, float]]:
        """
        Search the index for the most similar chunks to a query.

        Returns:
            List of (chunk_dict, distance) tuples, sorted by relevance.
        """
        if self.index is None or self.index.ntotal == 0:
            return []

        query_vector = np.array([embed_query(query)], dtype="float32")
        distances, indices = self.index.search(query_vector, top_k)

        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx == -1 or idx >= len(self.metadata):
                continue
            results.append((self.metadata[idx], float(dist)))
        return results

    def save(self, directory: str = DEFAULT_INDEX_DIR) -> None:
        """
        Persist the FAISS index and metadata to disk.
        """
        os.makedirs(directory, exist_ok=True)
        if self.index is not None:
            faiss.write_index(self.index, os.path.join(directory, INDEX_FILE_NAME))
        with open(os.path.join(directory, METADATA_FILE_NAME), "wb") as f:
            pickle.dump(self.metadata, f)

    def load(self, directory: str = DEFAULT_INDEX_DIR) -> bool:
        """
        Load a previously saved FAISS index and metadata from disk.

        Returns:
            True if loaded successfully, False if files were not found.
        """
        index_path = os.path.join(directory, INDEX_FILE_NAME)
        metadata_path = os.path.join(directory, METADATA_FILE_NAME)

        if not (os.path.exists(index_path) and os.path.exists(metadata_path)):
            return False

        self.index = faiss.read_index(index_path)
        self.dimension = self.index.d
        with open(metadata_path, "rb") as f:
            self.metadata = pickle.load(f)
        return True


if __name__ == "__main__":
    demo_chunks = [
        {"source": "policy.txt", "chunk_id": "c1", "text": "Employees get 20 paid leave days per year."},
        {"source": "policy.txt", "chunk_id": "c2", "text": "All laptops must be encrypted before use."},
    ]
    store = VectorStore()
    store.build(demo_chunks)
    results = store.search("How many leave days do employees get?", top_k=1)
    for chunk, distance in results:
        print(f"Match: {chunk['text']} (distance={distance:.4f})")
