"""
retriever.py
-------------
High-level retrieval orchestration: takes a user query, searches the
FAISS vector store, and formats the top matching chunks into a context
string ready to be injected into a prompt (the "R" in RAG).
"""

from __future__ import annotations

from typing import List, Dict

from utils.vector_store import VectorStore


def retrieve_relevant_chunks(
    vector_store: VectorStore, query: str, top_k: int = 4
) -> List[Dict]:
    """
    Retrieve the top-k most relevant chunks for a query.

    Args:
        vector_store: A loaded/populated VectorStore instance.
        query: The user's natural-language question.
        top_k: Number of chunks to retrieve.

    Returns:
        List of chunk dicts (source, chunk_id, text), best match first.
    """
    results = vector_store.search(query, top_k=top_k)
    # results are (chunk, distance) tuples sorted by ascending distance
    return [chunk for chunk, _distance in results]


def format_context(chunks: List[Dict]) -> str:
    """
    Combine retrieved chunks into a single context string with source
    attribution, suitable for inserting into an LLM prompt.
    """
    if not chunks:
        return "No relevant context was found in the knowledge base."

    formatted_blocks = []
    for i, chunk in enumerate(chunks, start=1):
        source = chunk.get("source", "unknown")
        text = chunk.get("text", "")
        formatted_blocks.append(f"[Source {i}: {source}]\n{text}")

    return "\n\n".join(formatted_blocks)


def retrieve_and_format(vector_store: VectorStore, query: str, top_k: int = 4) -> str:
    """
    Convenience wrapper: retrieve chunks and directly return formatted context.
    """
    chunks = retrieve_relevant_chunks(vector_store, query, top_k=top_k)
    return format_context(chunks)


if __name__ == "__main__":
    demo_chunks = [
        {"source": "policy.txt", "chunk_id": "c1", "text": "Employees get 20 paid leave days per year."},
    ]
    store = VectorStore()
    store.build(demo_chunks)
    context = retrieve_and_format(store, "leave policy")
    print(context)
