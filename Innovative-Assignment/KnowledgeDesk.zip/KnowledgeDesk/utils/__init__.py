"""
KnowledgeDesk utils package.

This package contains all core modules for the Enterprise Knowledge Assistant:
document readers (PDF, DOCX, OCR), chunking, embeddings, vector storage,
retrieval, prompt engineering, LLM integration, agent orchestration, and
evaluation utilities.
"""

__version__ = "0.1.0"
