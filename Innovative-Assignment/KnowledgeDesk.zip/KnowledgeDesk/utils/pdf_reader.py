"""
pdf_reader.py
--------------
Utility functions to extract text (and basic metadata) from PDF documents
using PyPDF2 (pypdf). Used as one of the ingestion sources for the
KnowledgeDesk RAG pipeline.
"""

from __future__ import annotations

import os
from typing import List, Dict

try:
    from pypdf import PdfReader
except ImportError:  # pragma: no cover
    PdfReader = None


def extract_text_from_pdf(file_path: str) -> str:
    """
    Extract raw text from a single PDF file.

    Args:
        file_path: Path to the .pdf file.

    Returns:
        A single string containing the concatenated text of all pages.
    """
    if PdfReader is None:
        raise ImportError("pypdf is not installed. Run: pip install pypdf")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"PDF file not found: {file_path}")

    reader = PdfReader(file_path)
    text_chunks = []
    for page_number, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text() or ""
        text_chunks.append(page_text)

    return "\n".join(text_chunks)


def extract_pages_with_metadata(file_path: str) -> List[Dict]:
    """
    Extract text page-by-page along with simple metadata, useful for
    keeping track of source page numbers during retrieval.

    Args:
        file_path: Path to the .pdf file.

    Returns:
        A list of dicts: [{"page": 1, "text": "...", "source": file_path}, ...]
    """
    if PdfReader is None:
        raise ImportError("pypdf is not installed. Run: pip install pypdf")

    reader = PdfReader(file_path)
    pages = []
    for page_number, page in enumerate(reader.pages, start=1):
        pages.append(
            {
                "page": page_number,
                "text": page.extract_text() or "",
                "source": os.path.basename(file_path),
            }
        )
    return pages


def load_all_pdfs(folder_path: str) -> List[Dict]:
    """
    Load and extract text from every PDF file inside a folder.

    Args:
        folder_path: Directory containing .pdf files.

    Returns:
        A list of dicts with keys: "source", "text".
    """
    documents = []
    if not os.path.isdir(folder_path):
        return documents

    for filename in sorted(os.listdir(folder_path)):
        if filename.lower().endswith(".pdf"):
            full_path = os.path.join(folder_path, filename)
            try:
                text = extract_text_from_pdf(full_path)
                documents.append({"source": filename, "text": text})
            except Exception as exc:  # pragma: no cover
                print(f"[pdf_reader] Failed to read {filename}: {exc}")
    return documents


if __name__ == "__main__":
    # Simple manual test / demo
    sample_dir = os.path.join("data", "pdfs")
    docs = load_all_pdfs(sample_dir)
    print(f"Loaded {len(docs)} PDF document(s) from {sample_dir}")
    for doc in docs:
        preview = doc["text"][:200].replace("\n", " ")
        print(f"- {doc['source']}: {preview}...")
