"""
evaluation.py
--------------
Evaluation utilities for the RAG pipeline. Provides:
1. A simple lexical overlap metric (no LLM required) for quick offline checks.
2. An LLM-as-judge evaluator (using Gemini) that scores faithfulness,
   relevance, and clarity for a question/context/answer triple.
"""

from __future__ import annotations

import json
import re
from typing import Dict, List

from utils.prompts import build_evaluation_prompt
from utils.llm import generate_response


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z0-9]+", text.lower())


def keyword_overlap_score(answer: str, reference: str) -> float:
    """
    A lightweight, dependency-free metric: fraction of reference
    keywords that also appear in the generated answer. Useful as a
    quick sanity check before/without calling an LLM judge.

    Returns:
        A score between 0.0 and 1.0.
    """
    reference_tokens = set(_tokenize(reference))
    if not reference_tokens:
        return 0.0

    answer_tokens = set(_tokenize(answer))
    overlap = reference_tokens.intersection(answer_tokens)
    return round(len(overlap) / len(reference_tokens), 3)


def llm_judge_evaluate(
    question: str, context: str, answer: str, reference: str = "N/A"
) -> Dict:
    """
    Use the Gemini LLM as a judge to score an answer on faithfulness,
    relevance, and clarity (1-5 each), returned as a parsed dict.

    Falls back to a default "unavailable" response if the LLM cannot
    be reached (e.g., missing API key) so evaluation code never crashes.
    """
    prompt = build_evaluation_prompt(
        question=question, context=context, answer=answer, reference=reference
    )

    try:
        raw_response = generate_response(prompt)
    except EnvironmentError as exc:
        return {
            "faithfulness": None,
            "relevance": None,
            "clarity": None,
            "comments": f"LLM judge unavailable: {exc}",
        }

    try:
        # Strip potential markdown code fences before parsing JSON.
        cleaned = raw_response.strip().strip("`").replace("json\n", "", 1)
        return json.loads(cleaned)
    except (json.JSONDecodeError, ValueError):
        return {
            "faithfulness": None,
            "relevance": None,
            "clarity": None,
            "comments": f"Could not parse judge output: {raw_response[:200]}",
        }


def evaluate_batch(samples: List[Dict]) -> List[Dict]:
    """
    Run evaluation over a batch of samples.

    Args:
        samples: List of dicts each containing "question", "context",
                 "answer", and optionally "reference".

    Returns:
        List of dicts merging the input sample with its evaluation scores.
    """
    results = []
    for sample in samples:
        scores = llm_judge_evaluate(
            question=sample.get("question", ""),
            context=sample.get("context", ""),
            answer=sample.get("answer", ""),
            reference=sample.get("reference", "N/A"),
        )
        keyword_score = None
        if sample.get("reference"):
            keyword_score = keyword_overlap_score(sample.get("answer", ""), sample["reference"])

        results.append({**sample, "llm_judge": scores, "keyword_overlap": keyword_score})
    return results


if __name__ == "__main__":
    sample = {
        "question": "How many paid leave days do employees get?",
        "context": "Employees get 20 paid leave days per year.",
        "answer": "Employees are entitled to 20 paid leave days annually.",
        "reference": "20 paid leave days per year",
    }
    print("Keyword overlap:", keyword_overlap_score(sample["answer"], sample["reference"]))
    print("LLM judge:", llm_judge_evaluate(**sample))
