"""
ocr_reader.py
--------------
Optical Character Recognition (OCR) module used to extract text from
scanned documents / images (e.g., policy screenshots, scanned forms)
using pytesseract + Pillow. Adds multimodal (image -> text) ingestion
support to the KnowledgeDesk RAG pipeline.

Requirements:
    - Tesseract OCR engine installed on the system
      (e.g. `sudo apt-get install tesseract-ocr` on Debian/Ubuntu,
      or https://github.com/UB-Mannheim/tesseract/wiki on Windows).
    - pip install pytesseract pillow
"""

from __future__ import annotations

import os
from typing import List, Dict

try:
    import pytesseract
    from PIL import Image
except ImportError:  # pragma: no cover
    pytesseract = None
    Image = None


SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".bmp", ".tiff")


def extract_text_from_image(file_path: str, lang: str = "eng") -> str:
    """
    Run OCR on a single image file and return the extracted text.

    Args:
        file_path: Path to an image file (png/jpg/jpeg/bmp/tiff).
        lang: Tesseract language code (default: English).

    Returns:
        Extracted text as a string.
    """
    if pytesseract is None or Image is None:
        raise ImportError(
            "pytesseract/Pillow not installed. Run: pip install pytesseract pillow"
        )

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Image file not found: {file_path}")

    try:
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image, lang=lang)
        return text.strip()
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract OCR engine not found on this system. "
            "Install it separately from https://github.com/tesseract-ocr/tesseract"
        ) from exc


def load_all_images(folder_path: str, lang: str = "eng") -> List[Dict]:
    """
    Run OCR on every supported image file inside a folder.

    Args:
        folder_path: Directory containing image files.
        lang: Tesseract language code.

    Returns:
        A list of dicts with keys: "source", "text".
    """
    documents = []
    if not os.path.isdir(folder_path):
        return documents

    for filename in sorted(os.listdir(folder_path)):
        if filename.lower().endswith(SUPPORTED_EXTENSIONS):
            full_path = os.path.join(folder_path, filename)
            try:
                text = extract_text_from_image(full_path, lang=lang)
                documents.append({"source": filename, "text": text})
            except Exception as exc:  # pragma: no cover
                print(f"[ocr_reader] Failed to OCR {filename}: {exc}")
    return documents


if __name__ == "__main__":
    sample_dir = os.path.join("data", "images")
    docs = load_all_images(sample_dir)
    print(f"OCR-processed {len(docs)} image(s) from {sample_dir}")
    for doc in docs:
        preview = doc["text"][:200].replace("\n", " ")
        print(f"- {doc['source']}: {preview}...")
