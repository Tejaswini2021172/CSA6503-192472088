"""
prompts.py
-----------
Centralized prompt engineering module. Defines reusable, structured
prompt templates for the RAG pipeline, the AI agent, and evaluation,
so prompt text is version-controlled and easy to iterate on.
"""

from __future__ import annotations

SYSTEM_PERSONA = (
    "You are KnowledgeDesk, an enterprise knowledge assistant. "
    "You answer employee questions strictly using the provided context "
    "from company documents. You are precise, concise, and professional. "
    "If the answer is not contained in the context, say you don't know "
    "instead of guessing."
)


RAG_PROMPT_TEMPLATE = """{system_persona}

### Context from company documents:
{context}

### Conversation history:
{history}

### Question:
{question}

### Instructions:
- Answer using ONLY the information in the context above.
- Cite the source document name(s) when possible.
- If the context does not contain the answer, respond: "I could not find this information in the knowledge base."
- Keep the answer clear and well-structured (use bullet points for lists).

### Answer:
"""


AGENT_SYSTEM_PROMPT = """{system_persona}

You are operating as an autonomous agent with access to the following tools:
{tool_descriptions}

Use the ReAct pattern:
Thought: reason about what to do next
Action: the tool to call, and its input
Observation: the result of the tool call
... (repeat Thought/Action/Observation as needed)
Final Answer: the final response to the user

Always ground your Final Answer in the Observations you collected.
"""


EVALUATION_PROMPT_TEMPLATE = """You are an impartial evaluator grading an AI assistant's answer.

### Question:
{question}

### Retrieved Context:
{context}

### Assistant's Answer:
{answer}

### Reference / Expected Answer (if available):
{reference}

Score the assistant's answer from 1 (poor) to 5 (excellent) on:
1. Faithfulness (is it grounded in the context, no hallucination?)
2. Relevance (does it actually answer the question?)
3. Clarity (is it well-written and easy to understand?)

Return your evaluation strictly as JSON in this format:
{{
  "faithfulness": <1-5>,
  "relevance": <1-5>,
  "clarity": <1-5>,
  "comments": "<short justification>"
}}
"""


def build_rag_prompt(context: str, question: str, history: str = "") -> str:
    """
    Fill in the RAG prompt template with the retrieved context, the
    conversation history, and the current question.
    """
    return RAG_PROMPT_TEMPLATE.format(
        system_persona=SYSTEM_PERSONA,
        context=context,
        history=history if history else "(no previous conversation)",
        question=question,
    )


def build_agent_prompt(tool_descriptions: str) -> str:
    """
    Fill in the agent system prompt with a description of available tools.
    """
    return AGENT_SYSTEM_PROMPT.format(
        system_persona=SYSTEM_PERSONA, tool_descriptions=tool_descriptions
    )


def build_evaluation_prompt(
    question: str, context: str, answer: str, reference: str = "N/A"
) -> str:
    """
    Fill in the evaluation prompt template used by the evaluation module
    to score an assistant's answer using an LLM-as-judge approach.
    """
    return EVALUATION_PROMPT_TEMPLATE.format(
        question=question, context=context, answer=answer, reference=reference
    )


if __name__ == "__main__":
    prompt = build_rag_prompt(
        context="[Source 1: leave_policy.txt]\nEmployees get 20 paid leave days per year.",
        question="How many paid leave days do I get?",
    )
    print(prompt)
