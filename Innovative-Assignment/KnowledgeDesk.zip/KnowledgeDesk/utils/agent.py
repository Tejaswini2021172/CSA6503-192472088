"""
agent.py
---------
A lightweight AI agent that can decide between multiple tools
(knowledge-base search, calculator, and general LLM reasoning) to
answer a user request. This is intentionally implemented with simple,
transparent routing logic on top of LangChain-style "Tool" objects so
it is easy to extend for a university project (e.g., add a web-search
tool, a SQL tool, etc.).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, List, Optional

from utils.vector_store import VectorStore
from utils.retriever import retrieve_and_format
from utils.prompts import build_rag_prompt, build_agent_prompt
from utils.llm import generate_response


@dataclass
class Tool:
    name: str
    description: str
    func: Callable[[str], str]


def make_knowledge_base_tool(vector_store: VectorStore) -> Tool:
    """
    Tool that searches the FAISS knowledge base and returns formatted context.
    """

    def _run(query: str) -> str:
        return retrieve_and_format(vector_store, query, top_k=4)

    return Tool(
        name="knowledge_base_search",
        description="Search internal company documents (policies, manuals) for relevant information.",
        func=_run,
    )


def make_calculator_tool() -> Tool:
    """
    Very small, safe calculator tool: only allows digits and basic
    arithmetic operators to avoid arbitrary code execution.
    """

    def _run(expression: str) -> str:
        if not re.fullmatch(r"[0-9\.\+\-\*\/\(\)\s]+", expression):
            return "Invalid expression: only numbers and + - * / ( ) are allowed."
        try:
            result = eval(expression, {"__builtins__": {}})  # noqa: S307 (sandboxed)
            return str(result)
        except Exception as exc:  # pragma: no cover
            return f"Error evaluating expression: {exc}"

    return Tool(
        name="calculator",
        description="Evaluate simple arithmetic expressions, e.g. '12 * (3 + 4)'.",
        func=_run,
    )


class KnowledgeDeskAgent:
    """
    Simple rule-based / LLM-assisted agent that routes a user query to
    the most appropriate tool, then asks Gemini to compose a final
    answer using the tool's output as context.
    """

    def __init__(self, tools: Optional[List[Tool]] = None):
        self.tools = tools or []

    def _tool_descriptions(self) -> str:
        return "\n".join(f"- {t.name}: {t.description}" for t in self.tools)

    def _select_tool(self, query: str) -> Tool:
        """
        Naive routing: use the calculator for arithmetic-looking queries,
        otherwise fall back to knowledge-base search.
        """
        looks_like_math = bool(re.fullmatch(r"[0-9\.\+\-\*\/\(\)\s]+", query.strip()))
        if looks_like_math:
            for tool in self.tools:
                if tool.name == "calculator":
                    return tool

        for tool in self.tools:
            if tool.name == "knowledge_base_search":
                return tool

        # Fallback: first available tool
        return self.tools[0]

    def run(self, query: str) -> str:
        """
        Execute the agent loop: select a tool, gather an observation,
        then generate a final natural-language answer.
        """
        if not self.tools:
            return "No tools configured for this agent."

        tool = self._select_tool(query)
        observation = tool.func(query)

        if tool.name == "calculator":
            return f"Result: {observation}"

        # For knowledge-base results, compose a grounded answer via the LLM.
        prompt = build_rag_prompt(context=observation, question=query)
        try:
            return generate_response(prompt)
        except EnvironmentError as exc:
            # No API key configured — return the raw context instead of failing.
            return f"[LLM unavailable: {exc}]\n\nRelevant context found:\n{observation}"


def build_default_agent(vector_store: VectorStore) -> KnowledgeDeskAgent:
    """
    Convenience factory that wires up the standard KnowledgeDesk toolset.
    """
    tools = [make_knowledge_base_tool(vector_store), make_calculator_tool()]
    return KnowledgeDeskAgent(tools=tools)


if __name__ == "__main__":
    demo_chunks = [
        {"source": "policy.txt", "chunk_id": "c1", "text": "Employees get 20 paid leave days per year."},
    ]
    store = VectorStore()
    store.build(demo_chunks)

    agent = build_default_agent(store)
    print(agent.run("2 + 2 * 5"))
    print(agent.run("How many leave days do employees get?"))
