"""
embeddings.py
--------------
Wraps Sentence-Transformers to generate dense vector embeddings for
text chunks. Used to embed documents before indexing into FAISS, and
to embed user queries at retrieval time.
"""

from __future__ import annotations

from typing import List

try:
    from sentence_transformers import SentenceTransformer
except ImportError:  # pragma: no cover
    SentenceTransformer = None

# A small, fast, high-quality general-purpose embedding model.
DEFAULT_MODEL_NAME = "all-MiniLM-L6-v2"

_model_cache = {}


def get_embedding_model(model_name: str = DEFAULT_MODEL_NAME):
    """
    Load (and cache) a SentenceTransformer embedding model.

    Args:
        model_name: HuggingFace model id / SentenceTransformers model name.

    Returns:
        A loaded SentenceTransformer instance.
    """
    if SentenceTransformer is None:
        raise ImportError(
            "sentence-transformers is not installed. "
            "Run: pip install sentence-transformers"
        )

    if model_name not in _model_cache:
        _model_cache[model_name] = SentenceTransformer(model_name)

    return _model_cache[model_name]


def embed_texts(texts: List[str], model_name: str = DEFAULT_MODEL_NAME) -> List[List[float]]:
    """
    Generate embeddings for a list of texts.

    Args:
        texts: List of strings to embed.
        model_name: Embedding model to use.

    Returns:
        List of embedding vectors (as plain Python lists of floats).
    """
    model = get_embedding_model(model_name)
    embeddings = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
    return embeddings.tolist()


def embed_query(query: str, model_name: str = DEFAULT_MODEL_NAME) -> List[float]:
    """
    Generate an embedding vector for a single query string.
    """
    return embed_texts([query], model_name=model_name)[0]


if __name__ == "__main__":
    sample_texts = [
        "Employees must complete security training annually.",
        "The company offers 20 days of paid leave per year.",
    ]
    vectors = embed_texts(sample_texts)
    print(f"Generated {len(vectors)} embeddings of dimension {len(vectors[0])}")
