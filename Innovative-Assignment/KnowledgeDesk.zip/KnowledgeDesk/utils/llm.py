"""
llm.py
-------
Wraps Google Gemini (via LangChain's ChatGoogleGenerativeAI) to provide
a single entry point for generating text completions across the app
(RAG answers, agent reasoning, and evaluation).
"""

from __future__ import annotations

import os
from typing import Optional

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
except ImportError:  # pragma: no cover
    ChatGoogleGenerativeAI = None

DEFAULT_MODEL_NAME = "gemini-1.5-flash"
DEFAULT_TEMPERATURE = 0.3

_llm_cache = {}


def get_llm(
    model_name: str = DEFAULT_MODEL_NAME,
    temperature: float = DEFAULT_TEMPERATURE,
    api_key: Optional[str] = None,
):
    """
    Build (and cache) a ChatGoogleGenerativeAI client.

    Args:
        model_name: Gemini model id (e.g. "gemini-1.5-flash", "gemini-1.5-pro").
        temperature: Sampling temperature.
        api_key: Optional explicit API key; falls back to GOOGLE_API_KEY env var.

    Returns:
        A configured ChatGoogleGenerativeAI instance.
    """
    if ChatGoogleGenerativeAI is None:
        raise ImportError(
            "langchain-google-genai is not installed. "
            "Run: pip install langchain-google-genai"
        )

    key = api_key or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise EnvironmentError(
            "GOOGLE_API_KEY is not set. Add it to your .env file "
            "(see .env.example) or export it in your shell."
        )

    cache_key = (model_name, temperature)
    if cache_key not in _llm_cache:
        _llm_cache[cache_key] = ChatGoogleGenerativeAI(
            model=model_name,
            temperature=temperature,
            google_api_key=key,
        )

    return _llm_cache[cache_key]


def generate_response(prompt: str, model_name: str = DEFAULT_MODEL_NAME) -> str:
    """
    Generate a single text response for a fully-formed prompt string.

    Args:
        prompt: The complete prompt (already includes context/instructions).
        model_name: Which Gemini model to use.

    Returns:
        The model's text response.
    """
    llm = get_llm(model_name=model_name)
    result = llm.invoke(prompt)
    # ChatGoogleGenerativeAI returns an AIMessage-like object with .content
    return getattr(result, "content", str(result))


if __name__ == "__main__":
    # NOTE: requires a valid GOOGLE_API_KEY to actually run.
    try:
        response = generate_response("Say hello in one short sentence.")
        print(response)
    except EnvironmentError as exc:
        print(f"[llm.py] Skipping live call: {exc}")
