# 📚 KnowledgeDesk

**Enterprise Knowledge Assistant** using Retrieval-Augmented Generation (RAG), Prompt Engineering, AI Agents, and Multimodal AI.

> University Generative AI Project — starter template

KnowledgeDesk lets employees ask natural-language questions about internal
company documents (policies, manuals, memos) and get grounded, cited answers.
It combines a document ingestion pipeline (PDF, DOCX, and OCR for images),
a FAISS vector database, Google Gemini as the LLM, a lightweight AI agent
with tool use, and an evaluation module — all wrapped in a Streamlit UI.

---

## ✨ Features

- **Multi-format ingestion**: PDF, DOCX, TXT, and image files (via OCR)
- **RAG pipeline**: chunking → Sentence-Transformers embeddings → FAISS similarity search → Gemini generation
- **Prompt engineering module**: centralized, versioned prompt templates
- **AI Agent**: routes queries between a knowledge-base search tool and a calculator tool
- **Multimodal AI**: OCR support for scanned documents / screenshots
- **Evaluation module**: LLM-as-judge scoring (faithfulness, relevance, clarity) + keyword overlap metric
- **Streamlit frontend**: upload documents, chat, run the agent, and evaluate answers — all in one app

---

## 🏗️ Project Structure

```
KnowledgeDesk/
│
├── app.py                     # Streamlit frontend (entry point)
├── requirements.txt           # Python dependencies
├── README.md                  # This file
├── .gitignore                 # Python + project-specific ignores
├── .env.example                # Template for environment variables
│
├── data/                       # Working ingestion folders (used at runtime)
│   ├── pdfs/
│   ├── docx/
│   └── images/
│
├── utils/                      # Core application modules
│   ├── __init__.py
│   ├── pdf_reader.py            # PDF text extraction (pypdf)
│   ├── docx_reader.py           # DOCX text extraction (python-docx)
│   ├── ocr_reader.py            # OCR for images (pytesseract)
│   ├── chunker.py               # Text splitting (LangChain)
│   ├── embeddings.py            # Sentence-Transformers embeddings
│   ├── vector_store.py          # FAISS vector database wrapper
│   ├── retriever.py             # Retrieval + context formatting
│   ├── prompts.py               # Prompt engineering templates
│   ├── llm.py                   # Google Gemini integration (LangChain)
│   ├── agent.py                 # AI agent with tool routing
│   └── evaluation.py            # LLM-as-judge + keyword evaluation
│
├── vector_db/                  # Persisted FAISS index + metadata (generated)
├── screenshots/                # App screenshots for documentation
└── sample_data/                # 3 dummy company policy documents for testing
    ├── remote_work_policy.txt
    ├── it_security_policy.pdf
    └── leave_expense_policy.docx
```

---

## 🚀 Getting Started

### 1. Prerequisites

- Python 3.10+
- [Tesseract OCR engine](https://github.com/tesseract-ocr/tesseract) installed on your system (required for the OCR module)
  - Ubuntu/Debian: `sudo apt-get install tesseract-ocr`
  - macOS: `brew install tesseract`
  - Windows: [installer here](https://github.com/UB-Mannheim/tesseract/wiki)
- A [Google Gemini API key](https://aistudio.google.com/app/apikey)

### 2. Clone & open in VS Code

```bash
git clone https://github.com/<your-username>/KnowledgeDesk.git
cd KnowledgeDesk
code .
```

### 3. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate      # On Windows: .venv\Scripts\activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure environment variables

```bash
cp .env.example .env
```

Then edit `.env` and add your Gemini API key:

```
GOOGLE_API_KEY=your_google_gemini_api_key_here
```

### 6. Run the app

```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`.

---

## 🧪 Testing with Sample Data

The `sample_data/` folder includes three dummy company policy documents you
can upload directly in the Streamlit sidebar to test the pipeline end-to-end:

| File | Format | Content |
|---|---|---|
| `remote_work_policy.txt` | TXT | Remote work eligibility, hours, security, leave |
| `it_security_policy.pdf` | PDF | Password rules, device security, incident reporting |
| `leave_expense_policy.docx` | DOCX | Annual/sick/parental leave, travel expense rules |

**Try asking:**
- "How many paid leave days do employees get?"
- "What is the minimum password length required?"
- "What is the daily meal expense limit for business travel?"

---

## 🧩 Architecture Overview

```
User Question
     │
     ▼
[ Streamlit UI ] ──▶ [ Retriever ] ──▶ [ FAISS Vector Store ] ──▶ Top-K Chunks
     │                                                                │
     │                                                                ▼
     │                                                     [ Prompt Engineering ]
     │                                                                │
     ▼                                                                ▼
[ AI Agent (optional) ]                                    [ Google Gemini LLM ]
     │                                                                │
     └────────────────────────────▶  Final Answer  ◀───────────────┘
                                          │
                                          ▼
                                  [ Evaluation Module ]
```

**Ingestion pipeline:** `pdf_reader.py` / `docx_reader.py` / `ocr_reader.py`
→ `chunker.py` → `embeddings.py` → `vector_store.py` (FAISS index saved to `vector_db/`)

---

## 🔧 Configuration Notes

- **Embedding model**: defaults to `all-MiniLM-L6-v2` (fast, CPU-friendly). Change in `utils/embeddings.py`.
- **LLM model**: defaults to `gemini-1.5-flash`. Change via `GEMINI_MODEL` in `.env` or directly in `utils/llm.py`.
- **Chunk size/overlap**: tune `DEFAULT_CHUNK_SIZE` / `DEFAULT_CHUNK_OVERLAP` in `utils/chunker.py`.
- **Vector index persistence**: the FAISS index and metadata are saved to `vector_db/` so the knowledge base survives app restarts.

---

## 📈 Possible Extensions (Ideas for Your Project Report)

- Add a web-search tool to the AI agent for open-domain questions
- Swap FAISS for a managed vector DB (Pinecone, Weaviate, Chroma)
- Add conversational memory using LangChain's memory modules
- Add authentication and multi-user document access control
- Add a RAGAS-based automated evaluation pipeline
- Deploy on Streamlit Community Cloud, Hugging Face Spaces, or Docker

---

## ⚠️ Disclaimer

All documents in `sample_data/` contain **fictional, dummy content**
generated purely for testing and academic demonstration purposes. They do
not represent any real company's actual policies.

---

## 📄 License

This starter project is provided for educational use as part of a
university Generative AI course project. Feel free to fork, modify, and
extend it for your coursework.
