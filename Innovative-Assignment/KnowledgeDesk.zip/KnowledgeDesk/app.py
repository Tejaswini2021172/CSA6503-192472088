"""
app.py
-------
KnowledgeDesk — Enterprise Knowledge Assistant
Streamlit front-end that ties together document ingestion (PDF/DOCX/OCR),
chunking, embeddings, FAISS retrieval, prompt engineering, the Gemini LLM,
an AI agent, and evaluation into a single interactive app.

Run with:
    streamlit run app.py
"""

import os
import sys
import tempfile

import streamlit as st
from dotenv import load_dotenv

# Ensure local imports work regardless of the working directory.
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.pdf_reader import extract_text_from_pdf
from utils.docx_reader import extract_text_from_docx
from utils.ocr_reader import extract_text_from_image
from utils.chunker import chunk_documents
from utils.vector_store import VectorStore
from utils.retriever import retrieve_and_format
from utils.prompts import build_rag_prompt
from utils.llm import generate_response
from utils.agent import build_default_agent
from utils.evaluation import keyword_overlap_score, llm_judge_evaluate

load_dotenv()

st.set_page_config(page_title="KnowledgeDesk", page_icon="📚", layout="wide")

VECTOR_DB_DIR = "vector_db"


# --------------------------------------------------------------------------
# Session state initialization
# --------------------------------------------------------------------------
if "vector_store" not in st.session_state:
    store = VectorStore()
    if not store.load(VECTOR_DB_DIR):
        store.dimension = None  # Not built yet
    st.session_state.vector_store = store

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # list of (role, message)


def get_store() -> VectorStore:
    return st.session_state.vector_store


# --------------------------------------------------------------------------
# Sidebar: document ingestion
# --------------------------------------------------------------------------
st.sidebar.title("📚 KnowledgeDesk")
st.sidebar.caption("Enterprise Knowledge Assistant — RAG + Agents + Multimodal AI")

st.sidebar.header("1. Ingest Documents")
uploaded_files = st.sidebar.file_uploader(
    "Upload PDF, DOCX, TXT, or image files",
    type=["pdf", "docx", "txt", "png", "jpg", "jpeg"],
    accept_multiple_files=True,
)

if st.sidebar.button("Build / Update Knowledge Base", use_container_width=True):
    if not uploaded_files:
        st.sidebar.warning("Please upload at least one document first.")
    else:
        raw_documents = []
        with st.spinner("Extracting text from uploaded documents..."):
            for uploaded in uploaded_files:
                suffix = os.path.splitext(uploaded.name)[1].lower()
                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(uploaded.getbuffer())
                    tmp_path = tmp.name

                try:
                    if suffix == ".pdf":
                        text = extract_text_from_pdf(tmp_path)
                    elif suffix == ".docx":
                        text = extract_text_from_docx(tmp_path)
                    elif suffix == ".txt":
                        with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                            text = f.read()
                    elif suffix in (".png", ".jpg", ".jpeg"):
                        text = extract_text_from_image(tmp_path)
                    else:
                        text = ""

                    if text.strip():
                        raw_documents.append({"source": uploaded.name, "text": text})
                except Exception as exc:
                    st.sidebar.error(f"Failed to process {uploaded.name}: {exc}")
                finally:
                    os.unlink(tmp_path)

        if raw_documents:
            with st.spinner("Chunking and embedding documents into FAISS..."):
                chunks = chunk_documents(raw_documents)
                store = get_store()
                store.build(chunks)
                store.save(VECTOR_DB_DIR)
            st.sidebar.success(
                f"Knowledge base built: {len(raw_documents)} document(s), {len(chunks)} chunk(s)."
            )
        else:
            st.sidebar.warning("No extractable text was found in the uploaded files.")

st.sidebar.header("2. Mode")
mode = st.sidebar.radio(
    "Interaction mode",
    ["RAG Q&A", "AI Agent", "Evaluation"],
    help="RAG Q&A answers directly from retrieved context. "
    "AI Agent can also use tools like a calculator. "
    "Evaluation scores a given answer against the retrieved context.",
)

st.sidebar.info(
    "Set your `GOOGLE_API_KEY` in a `.env` file (see `.env.example`) "
    "to enable live Gemini responses."
)


# --------------------------------------------------------------------------
# Main panel
# --------------------------------------------------------------------------
st.title("📚 KnowledgeDesk")
st.caption("Enterprise Knowledge Assistant — RAG · Prompt Engineering · AI Agents · Multimodal AI")

store = get_store()
kb_ready = store.index is not None and getattr(store.index, "ntotal", 0) > 0

if not kb_ready:
    st.warning(
        "No knowledge base loaded yet. Upload documents in the sidebar and click "
        "**Build / Update Knowledge Base** to get started."
    )

if mode == "RAG Q&A":
    st.subheader("Ask a question about your documents")
    question = st.text_input("Your question", placeholder="e.g. What is the company's leave policy?")

    if st.button("Ask", type="primary") and question:
        if not kb_ready:
            st.error("Please build the knowledge base first.")
        else:
            with st.spinner("Retrieving relevant context..."):
                context = retrieve_and_format(store, question, top_k=4)

            with st.expander("🔍 Retrieved context"):
                st.text(context)

            history_text = "\n".join(f"{role}: {msg}" for role, msg in st.session_state.chat_history[-6:])
            prompt = build_rag_prompt(context=context, question=question, history=history_text)

            with st.spinner("Generating answer with Gemini..."):
                try:
                    answer = generate_response(prompt)
                except EnvironmentError as exc:
                    answer = f"⚠️ {exc}\n\nHere is the retrieved context instead:\n\n{context}"

            st.session_state.chat_history.append(("User", question))
            st.session_state.chat_history.append(("Assistant", answer))

            st.markdown("### 🤖 Answer")
            st.write(answer)

    if st.session_state.chat_history:
        with st.expander("💬 Conversation history"):
            for role, msg in st.session_state.chat_history:
                st.markdown(f"**{role}:** {msg}")

elif mode == "AI Agent":
    st.subheader("Ask the AI Agent")
    st.caption("The agent can route your query to the knowledge base or a calculator tool.")
    agent_query = st.text_input("Your request", placeholder="e.g. 15 * (200 + 50)  OR  What is the refund policy?")

    if st.button("Run Agent", type="primary") and agent_query:
        agent = build_default_agent(store)
        with st.spinner("Agent is thinking..."):
            result = agent.run(agent_query)
        st.markdown("### 🧠 Agent Response")
        st.write(result)

elif mode == "Evaluation":
    st.subheader("Evaluate an Answer")
    st.caption("Score an assistant answer for faithfulness, relevance, and clarity.")

    eval_question = st.text_area("Question", height=80)
    eval_context = st.text_area("Context (retrieved passages)", height=120)
    eval_answer = st.text_area("Assistant Answer", height=120)
    eval_reference = st.text_area("Reference Answer (optional)", height=80)

    if st.button("Evaluate", type="primary") and eval_question and eval_answer:
        with st.spinner("Scoring answer..."):
            judge_result = llm_judge_evaluate(
                question=eval_question,
                context=eval_context,
                answer=eval_answer,
                reference=eval_reference or "N/A",
            )
            keyword_score = (
                keyword_overlap_score(eval_answer, eval_reference) if eval_reference else None
            )

        st.markdown("### 📊 Evaluation Results")
        st.json(judge_result)
        if keyword_score is not None:
            st.metric("Keyword Overlap Score", keyword_score)

st.divider()
st.caption(
    "KnowledgeDesk · University Generative AI Project · "
    "Built with Streamlit, LangChain, Google Gemini, FAISS, and Sentence-Transformers."
)
